#!/usr/bin/env python
# -*- coding: utf-8 -*-

## Licensed under the Apache License, Version 2.0 (the "License");
## you may not use this file except in compliance with the License.
## You may obtain a copy of the License at
##
##      http://www.apache.org/licenses/LICENSE-2.0
##
## Unless required by applicable law or agreed to in writing, software
## distributed under the License is distributed on an "AS IS" BASIS,
## WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
## See the License for the specific language governing permissions and
## limitations under the License.

"""Converts the XML representation of the documentation to text format.

Usage:

  xtract.py [options] files*
  xtract.py [options] <files

Options:

-S/--insert_s_tokens (False)
  Wrap texts in "<s>" and "</s>"
-l/--preserve_line_breaks (False)
  Preserve line breaks as document boundaries
-l/--preserve_side_breaks (False)
  Preserve side breaks (for multiside "texts") as document boundaries
-u/--preserve_uncertainty (False)
  Preserve annotations about uncertain glyphs
-r/--raw (False)
  If set, then do not clean up ">" characters in the text.
"""

__author__ = 'rws@xoba.com (Richard Sproat)'

OPTIONS_ = """(-S/--insert_s_tokens)
              (-l/--preserve_line_breaks)
              (-r/--raw)
              (-s/--preserve_side_breaks)
              (-u/--preserve_uncertainty)
              (-?/--help)"""

import getopt
import sys
import xml.sax.handler

def CleanText(text):
  """Clean up malformed symbols. These should eventually be cleaned in the
  source.
  """
  text = text.replace('>', '')
  return text

## TODO(rws): Implement sensitivity to circular_document in XmlHandler

class LinearizationOptions:
  def __init__(self):
    self.insert_s_tokens_ = False
    self.preserve_line_breaks_as_doc_boundaries_ = False
    self.preserve_side_breaks_as_doc_boundaries_ = False
    self.preserve_circular_document_ = False
    self.preserve_uncertainty_ = False
    self.clean_text_ = True


class XmlHandler(xml.sax.handler.ContentHandler):
  def __init__(self, linearization_options):
    self.parser_ = xml.sax.make_parser()
    self.parser_.setContentHandler(self)
    self.documents_ = []
    self.text_ = []
    self.thistext_ = ''
    self.in_description_ = False
    self.in_symbol_ = False
    self.in_title_ = False
    self.options_ = linearization_options
    self.uncertain_ = False

  def startElement(self, name, attributes):
    if name == 'description':
      self.in_description_ = True
    elif name == 'symbol':
      self.in_symbol_ = True
      self.uncertain_ = False
      if self.options_.preserve_uncertainty_:
        if ('reliability' in attributes and
            attributes['reliability'] == 'uncertain'):
          self.uncertain_ = True
    elif name == 'title':
      if self.in_symbol_:
        self.thistext_ = ''
        self.in_title_ = True

  def AddData(self, data):
    clean = data.encode('utf8').strip().replace(' ', '_')
    if self.uncertain_: clean = clean + '?'
    if self.options_.clean_text_:
      self.thistext_ += CleanText(clean)
    else:
      self.thistext_ += clean

  def characters(self, data):
    if self.in_symbol_ and self.in_title_ and not self.in_description_:
      self.AddData(data)
 
  def endElement(self, name):
    if name == 'description':
      self.in_description_ = False
    elif name == 'document':
      if self.text_: self.documents_.append(' '.join(self.text_))
      self.text_ = []
    elif name == 'line':
      if self.options_.preserve_line_breaks_as_doc_boundaries_ and self.text_:
        self.documents_.append(' '.join(self.text_))
        self.text_ = []
    elif name == 'side':
      if self.options_.preserve_side_breaks_as_doc_boundaries_ and self.text_:
        self.documents_.append(' '.join(self.text_))
        self.text_ = []
    elif name == 'symbol':
      self.in_symbol_ = False
    elif name == 'title':
      if self.in_symbol_:
        if self.thistext_:
          self.text_.append(self.thistext_)
          self.thistext_ = ''
        self.in_title_ = False

  def Decode(self, filename):
    if filename == '-':
      self.parser_.parse(sys.stdin)
    else:
      self.parser_.parse(filename)

  def LinearizeDocuments(self, printer=False):
    docs = []
    for doc in self.documents_:
      try:
        if self.options_.insert_s_tokens_:
          doc = '<s> %s </s>' % doc
        if printer: print doc
        docs.append(doc.split())
      except IOError:
        sys.exit(1)
    return docs


def ParseAndLinearize(file, linearization_options, printer=False):
  handler = XmlHandler(linearization_options)
  handler.Decode(file)
  return handler.LinearizeDocuments(printer)


def Usage(name):
  print 'Usage: %s %s' % (name, OPTIONS_)


def ParseOptions():
  options = LinearizationOptions()  
  try:
    opts, args = getopt.getopt(sys.argv[1:], 'Slsru?',
                               ['insert_s_tokens',
                                'preserve_line_breaks',
                                'preserve_side_breaks',
                                'preserve_uncertainty',
                                'raw',
                                'help',
                                ])
  except getopt.GetoptError:
    Usage(sys.argv[0])
    sys.exit(2)
  for op, a in opts:
    if op in ('-S', '--insert_s_tokens'):
      options.insert_s_tokens_ = True
    elif op in ('-l', '--preserve_line_breaks'):
      options.preserve_line_breaks_as_doc_boundaries_ = True
    elif op in ('-s', '--preserve_side_breaks'):
      options.preserve_side_breaks_as_doc_boundaries_ = True
    elif op in ('-u', '--preserve_uncertainty'):
      options.preserve_uncertainty_ = True
    elif op in ('-r' '--raw'):
      options.clean_text_ = False
    elif op in ('-?', '--help'):
      Usage(sys.argv[0])
      sys.exit()
  return options, args


if __name__ == '__main__':
  options, args = ParseOptions()
  if len(args) > 0:
    for file in args:
      ParseAndLinearize(file, options, True)
  else:
    ParseAndLinearize('-', options, True)
