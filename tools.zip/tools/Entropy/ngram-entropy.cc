// ngram-entropy.cc
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Copyright 2012 Richard Sproat
// Author: rws@xoba.com (Richard Sproat)
//
// \file
// Compute conditional n-gram entropies over a language model

#include <fst/extensions/far/far.h>
#include <fst/fst.h>
#include <ngram/ngram-output.h>
#include <string>
#include <vector>

using namespace fst;
using namespace ngram;
using std::string;
using std::vector;


typedef StdArc::StateId StateId;
typedef StdArc::Label Label;


// Copied from NGramModel::FindNGramInModel(), which is a protected method.

bool FindLabel(NGramOutput* model, StateId *mst, Label label, double *cost) {
  StdMutableFst* fst = model->GetMutableFst();
  Label backoff_label = model->BackoffLabel();
  if (label < 0) return 0;
  StateId currstate = (*mst);
  (*cost) = 0;
  (*mst) = -1;
  while ((*mst) < 0) {
    Matcher<StdFst> matcher(*fst, MATCH_INPUT);
    matcher.SetState(currstate);
    if (matcher.Find(label)) {  // arc found out of current state
      StdArc arc = matcher.Value();
      (*mst) = arc.nextstate;  // assign destination as new model state
      (*cost) += arc.weight.Value();  // add cost to total
    } else if (matcher.Find(backoff_label)) {  // follow backoff arc
      currstate = -1;
      for (; !matcher.Done(); matcher.Next()) {
	StdArc arc = matcher.Value();
	if (arc.ilabel == backoff_label) {
	  currstate = arc.nextstate;  // make current state backoff state
	  (*cost) += arc.weight.Value();  // add in backoff cost
	}
      }
      if (currstate < 0) return 0;
    } else {
      return 0;  // Found label in symbol list, but not in model
    }
  }
  return 1;
}


void NgramSearch(NGramOutput* model, StateId state, const SymbolTable* syms,
		 int order, vector<Label> vec,
		 double log_joint, double log_cond) {
  if (order < 0) {
    LOG(ERROR) << "Illicit order: " << order;
  }
  if (order == 0) {
    for (size_t i = 0; i < vec.size(); ++i) {
      string symbol = syms->Find(vec[i]);
      if (i) cout << " ";
      cout << symbol;
    }
    double joint = exp(-log_joint);
    double cond_ent = joint * log_cond;
    double block_ent = joint * log_joint;
    cout << "\t"
	 << joint << "\t"
	 << log_cond << "\t"
	 << cond_ent << "\t"
	 << block_ent
	 << endl;
    return;
  }
  SymbolTableIterator siter(*syms);
  while (!siter.Done()) {
    Label lab = siter.Value();
    if (lab) {
      double cost = 0;
      StateId nextstate = state;
      if (!FindLabel(model, &nextstate, lab, &cost)) {
	LOG(FATAL) << "Cannot find label "
		   << lab
		   << " at state "
		   << state
		   << endl;
      }
      vec.push_back(lab);
      NgramSearch(model, nextstate, syms, order - 1, vec, log_joint + cost, cost);
      vec.pop_back();
    }
    siter.Next();
  }
}


int main(int argc, char **argv) {
  string usage =
    "Compute conditional entropies for all ngrams in a language model .\n\n  Usage: ";
  usage += argv[0];
  usage += " [--options] ngram.fst\n";
  InitFst(usage.c_str(), &argc, &argv, true);
  string in1_name = strcmp(argv[1], "-") != 0 ? argv[1] : "";
  StdMutableFst *lmfst = StdMutableFst::Read(in1_name, true);
  if (!lmfst) return 1;
  const SymbolTable* syms = lmfst->InputSymbols();
  if (!syms)
    LOG(FATAL) << "No symbol table found in fst";
  NGramOutput model(lmfst);
  StateId unigram = model.UnigramState();
  if (unigram == -1)
    LOG(FATAL) << "No conditional entropy computation for unigram model";
  vector<Label> vec;
  NgramSearch(&model, unigram, syms, model.HiOrder(), vec, 0, 0);
  delete lmfst;
}

